<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'AI Trade App'); ?></title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        :root {
            --primary-color: #0d6efd;
            --secondary-color: #198754;
            --success-color: #198754;
            --info-color: #0dcaf0;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
            --light-color: #f8f9fa;
            --dark-color: #212529;
        }
        
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar-brand {
            font-weight: bold;
            color: var(--primary-color) !important;
        }
        
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            border-radius: 8px;
            margin: 2px 10px;
            transition: all 0.3s ease;
        }
        
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            color: white;
            background-color: rgba(255,255,255,0.1);
            transform: translateX(5px);
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
        }
        
        .main-content {
            padding: 20px;
        }
        
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        
        .card:hover {
            transform: translateY(-2px);
        }
        
        .card-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            border-radius: 15px 15px 0 0 !important;
            border: none;
        }
        
        .stats-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .stats-card .card-body {
            padding: 1.5rem;
        }
        
        .stats-card h3 {
            font-size: 2rem;
            font-weight: bold;
            margin: 0;
        }
        
        .stats-card p {
            margin: 0;
            opacity: 0.9;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            border-radius: 8px;
            padding: 10px 20px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }
        
        .table {
            border-radius: 10px;
            overflow: hidden;
        }
        
        .table thead th {
            background-color: var(--primary-color);
            color: white;
            border: none;
            font-weight: 500;
        }
        
        .badge {
            padding: 8px 12px;
            border-radius: 20px;
            font-weight: 500;
        }
        
        .text-success {
            color: var(--success-color) !important;
        }
        
        .text-danger {
            color: var(--danger-color) !important;
        }
        
        .text-warning {
            color: var(--warning-color) !important;
        }
        
        .text-info {
            color: var(--info-color) !important;
        }
        
        .mobile-menu-btn {
            display: none;
        }

        .mobile-menu-offcanvas {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        }

        .mobile-menu-offcanvas .offcanvas-header {
            border-bottom: 1px solid rgba(255,255,255,0.2);
        }

        .mobile-menu-offcanvas .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            border-radius: 8px;
            margin: 2px 10px;
            transition: all 0.3s ease;
        }

        .mobile-menu-offcanvas .nav-link:hover,
        .mobile-menu-offcanvas .nav-link.active {
            color: white;
            background-color: rgba(255,255,255,0.1);
        }

        .mobile-menu-offcanvas .nav-link i {
            margin-right: 10px;
            width: 20px;
        }

        @media (max-width: 768px) {
            .sidebar {
                display: none !important;
            }

            .mobile-menu-btn {
                display: block;
            }

            .main-content {
                padding: 10px;
                width: 100%;
            }

            .top-nav-section {
                width: 100%;
            }
        }
    </style>
    
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-3 col-lg-2 d-md-block sidebar collapse">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4">
                        <div class="mb-3">
                            <img src="<?php echo e(asset('admin-assets/img/nexa-ai-robot.jpg')); ?>" alt="Nexa Trades Logo" style="max-width: 80px; height: auto; border-radius: 12px; box-shadow: 0 4px 10px rgba(0,0,0,0.2);">
                        </div>
                        <h4 class="text-white mb-1">Nexa Trades</h4>
                        <small class="text-white-50">Customer Panel</small>
                    </div>
                    
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('customer.dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('customer.dashboard')); ?>">
                                <i class="bi bi-house-door"></i>
                                Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('customer.trading.*') ? 'active' : ''); ?>" href="<?php echo e(route('customer.trading.index')); ?>">
                                <i class="bi bi-graph-up"></i>
                                Trading
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('customer.market.*') ? 'active' : ''); ?>" href="<?php echo e(route('customer.market.index')); ?>">
                                <i class="bi bi-currency-exchange"></i>
                                Market
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('customer.wallet.*') ? 'active' : ''); ?>" href="<?php echo e(route('customer.wallet.index')); ?>">
                                <i class="bi bi-wallet2"></i>
                                Wallet
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('customer.wallet.deposit') ? 'active' : ''); ?>" href="<?php echo e(route('customer.wallet.deposit')); ?>">
                                <i class="bi bi-cash-coin"></i>
                                Deposits
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('customer.agents.*') ? 'active' : ''); ?>" href="<?php echo e(route('customer.agents.index')); ?>">
                                <i class="bi bi-robot"></i>
                                AI Agents
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('customer.referrals.*') ? 'active' : ''); ?>" href="<?php echo e(route('customer.referrals.index')); ?>">
                                <i class="bi bi-people"></i>
                                Referrals
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('customer.invoices.*') ? 'active' : ''); ?>" href="<?php echo e(route('customer.invoices.index')); ?>">
                                <i class="bi bi-receipt"></i>
                                Invoices
                                <?php if(isset($unpaidCount) && $unpaidCount > 0): ?>
                                    <span class="badge bg-danger ms-2"><?php echo e($unpaidCount); ?></span>
                                <?php endif; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('customer.support.*') ? 'active' : ''); ?>" href="<?php echo e(route('customer.support.index')); ?>">
                                <i class="bi bi-headset"></i>
                                Support
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('customer.profile.*') ? 'active' : ''); ?>" href="<?php echo e(route('customer.profile.index')); ?>">
                                <i class="bi bi-person"></i>
                                Profile
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content">
                <!-- Top Navigation -->
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom top-nav-section">
                    <h1 class="h2"><?php echo $__env->yieldContent('page-title', 'Dashboard'); ?></h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <!-- Mobile Menu Button -->
                        <button class="btn btn-primary mobile-menu-btn me-2" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobileMenu" aria-controls="mobileMenu">
                            <i class="bi bi-list"></i>
                        </button>
                        <div class="btn-group me-2">
                            <button type="button" class="btn btn-sm btn-outline-secondary">
                                <i class="bi bi-bell"></i>
                                <span class="d-none d-md-inline">Notifications</span>
                            </button>
                        </div>
                        <div class="dropdown">
                            <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                <i class="bi bi-person-circle"></i>
                                <span class="d-none d-md-inline"><?php echo e(Auth::user()->name); ?></span>
                            </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="<?php echo e(route('customer.profile.index')); ?>">Profile</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('customer.wallet.index')); ?>">Wallet</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="dropdown-item">Logout</button>
                                    </form>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- Page Content -->
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
    </div>

    <!-- Mobile Menu Offcanvas -->
    <div class="offcanvas offcanvas-end mobile-menu-offcanvas" tabindex="-1" id="mobileMenu" aria-labelledby="mobileMenuLabel">
        <div class="offcanvas-header">
            <div class="d-flex align-items-center">
                <img src="<?php echo e(asset('admin-assets/img/nexa-ai-robot.jpg')); ?>" alt="Nexa Trades Logo" style="max-width: 50px; height: auto; border-radius: 12px; box-shadow: 0 4px 10px rgba(0,0,0,0.2); margin-right: 10px;">
                <div>
                    <h5 class="offcanvas-title text-white mb-0" id="mobileMenuLabel">Nexa Trades</h5>
                    <small class="text-white-50">Customer Panel</small>
                </div>
            </div>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link mobile-menu-link <?php echo e(request()->routeIs('customer.dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('customer.dashboard')); ?>">
                        <i class="bi bi-house-door"></i>
                        Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link mobile-menu-link <?php echo e(request()->routeIs('customer.trading.*') ? 'active' : ''); ?>" href="<?php echo e(route('customer.trading.index')); ?>">
                        <i class="bi bi-graph-up"></i>
                        Trading
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link mobile-menu-link <?php echo e(request()->routeIs('customer.market.*') ? 'active' : ''); ?>" href="<?php echo e(route('customer.market.index')); ?>">
                        <i class="bi bi-currency-exchange"></i>
                        Market
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link mobile-menu-link <?php echo e(request()->routeIs('customer.wallet.*') ? 'active' : ''); ?>" href="<?php echo e(route('customer.wallet.index')); ?>">
                        <i class="bi bi-wallet2"></i>
                        Wallet
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link mobile-menu-link <?php echo e(request()->routeIs('customer.wallet.deposit') ? 'active' : ''); ?>" href="<?php echo e(route('customer.wallet.deposit')); ?>">
                        <i class="bi bi-cash-coin"></i>
                        Deposits
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link mobile-menu-link <?php echo e(request()->routeIs('customer.agents.*') ? 'active' : ''); ?>" href="<?php echo e(route('customer.agents.index')); ?>">
                        <i class="bi bi-robot"></i>
                        AI Agents
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link mobile-menu-link <?php echo e(request()->routeIs('customer.referrals.*') ? 'active' : ''); ?>" href="<?php echo e(route('customer.referrals.index')); ?>">
                        <i class="bi bi-people"></i>
                        Referrals
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link mobile-menu-link <?php echo e(request()->routeIs('customer.invoices.*') ? 'active' : ''); ?>" href="<?php echo e(route('customer.invoices.index')); ?>">
                        <i class="bi bi-receipt"></i>
                        Invoices
                        <?php if(isset($unpaidCount) && $unpaidCount > 0): ?>
                            <span class="badge bg-danger ms-2"><?php echo e($unpaidCount); ?></span>
                        <?php endif; ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link mobile-menu-link <?php echo e(request()->routeIs('customer.support.*') ? 'active' : ''); ?>" href="<?php echo e(route('customer.support.index')); ?>">
                        <i class="bi bi-headset"></i>
                        Support
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link mobile-menu-link <?php echo e(request()->routeIs('customer.profile.*') ? 'active' : ''); ?>" href="<?php echo e(route('customer.profile.index')); ?>">
                        <i class="bi bi-person"></i>
                        Profile
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <!-- Bootstrap 5 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <script>
        // Ensure mobile menu links work correctly and close menu after navigation
        document.addEventListener('DOMContentLoaded', function() {
            const mobileMenuLinks = document.querySelectorAll('.mobile-menu-link');
            const mobileMenu = document.getElementById('mobileMenu');
            
            mobileMenuLinks.forEach(function(link) {
                link.addEventListener('click', function(e) {
                    // Get the href to ensure it's a valid link
                    const href = this.getAttribute('href');
                    
                    // Only close menu if it's not a hash or empty link
                    if (href && href !== '#' && href !== '') {
                        // Close the menu after navigation starts
                        setTimeout(function() {
                            const offcanvas = bootstrap.Offcanvas.getInstance(mobileMenu);
                            if (offcanvas) {
                                offcanvas.hide();
                            }
                        }, 150);
                    }
                });
            });
            
            // Also handle menu close on page navigation
            window.addEventListener('popstate', function() {
                const offcanvas = bootstrap.Offcanvas.getInstance(mobileMenu);
                if (offcanvas) {
                    offcanvas.hide();
                }
            });
        });
    </script>
    
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\laragon\www\TradingApp\resources\views/layouts/customer-layout.blade.php ENDPATH**/ ?>