<?php $__env->startSection('title', 'Manage Rent a Bot Plans'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h3 class="card-title">Rent a Bot Packages</h3>
                    <a href="<?php echo e(route('admin.rent-bot-packages.create')); ?>" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Add Package
                    </a>
                </div>
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Allowed Bots</th>
                                    <th>Allowed Trades</th>
                                    <th>Amount ($)</th>
                                    <th>Validity</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($package->id); ?></td>
                                        <td><?php echo e($package->allowed_bots); ?></td>
                                        <td><?php echo e($package->allowed_trades); ?></td>
                                        <td><?php echo e(number_format($package->amount, 2)); ?></td>
                                        <td class="text-capitalize"><?php echo e($package->validity); ?></td>
                                        <td>
                                            <?php if($package->status): ?>
                                                <span class="badge bg-success">Active</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger">Disabled</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('admin.rent-bot-packages.edit', $package->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                                            <form action="<?php echo e(route('admin.rent-bot-packages.destroy', $package->id)); ?>" method="POST" style="display:inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">No packages found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-3">
                        <?php echo e($packages->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\TradingApp\resources\views/admin/rent-bot-packages/index.blade.php ENDPATH**/ ?>