<div class="btn-group" role="group">
    <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="btn btn-sm btn-warning">
        <i class="bi bi-pencil-square"></i> Edit
    </a>
    <form action="<?php echo e(route('admin.users.destroy', $user)); ?>" method="POST" onsubmit="return confirm('Are you sure?')">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button class="btn btn-sm btn-danger">
            <i class="bi bi-trash"></i> Delete
        </button>
    </form>
</div>
<?php /**PATH D:\laragon\www\ai-trade-app\resources\views/admin/users/partials/actions.blade.php ENDPATH**/ ?>