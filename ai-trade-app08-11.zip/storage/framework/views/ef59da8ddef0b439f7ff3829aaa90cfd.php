<?php $__env->startSection('title', 'Trading - AI Trade App'); ?>
<?php $__env->startSection('page-title', 'Trading'); ?>

<?php $__env->startSection('content'); ?>
<?php if($activePackages->count() > 0): ?>
<div class="row mb-4">
    <div class="col-12">
        <div class="card border-primary">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="bi bi-box-seam"></i> Active Packages</h5>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <?php $__currentLoopData = $activePackages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card h-100">
                            <div class="card-body">
                                <h6 class="card-title text-primary">
                                    <i class="bi bi-robot"></i> <?php echo e($package['title']); ?>

                                </h6>
                                <div class="mb-2">
                                    <span class="badge bg-success">Active</span>
                                </div>
                                <div class="mt-3">
                                    <strong>Available Bots:</strong>
                                    <span class="text-primary fs-4 ms-2"><?php echo e($package['available_bots']); ?></span>
                                </div>
                                <?php if($package['type'] === 'Rent A Bot' && isset($package['plan_details']['allowed_trades'])): ?>
                                <div class="mt-2">
                                    <small class="text-muted">Allowed Trades: <?php echo e($package['plan_details']['allowed_trades']); ?></small>
                                </div>
                                <?php elseif($package['type'] === 'Sharing Nexa' && isset($package['plan_details']['trades_per_day'])): ?>
                                <div class="mt-2">
                                    <small class="text-muted">Trades/Day: <?php echo e($package['plan_details']['trades_per_day']); ?></small>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-graph-up"></i> Trading History</h5>
            </div>
            <div class="card-body">
                <?php if($trades->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Symbol</th>
                                <th>Side</th>
                                <th>Amount</th>
                                <th>Price</th>
                                <th>P&L</th>
                                <th>Status</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $trades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($trade->symbol); ?></td>
                                <td>
                                    <span class="badge <?php echo e($trade->side === 'buy' ? 'bg-success' : 'bg-danger'); ?>">
                                        <?php echo e(strtoupper($trade->side)); ?>

                                    </span>
                                </td>
                                <td>$<?php echo e(number_format($trade->quantity, 4)); ?></td>
                                <td>$<?php echo e(number_format($trade->price, 2)); ?></td>
                                <td class="<?php echo e($trade->profit_loss >= 0 ? 'text-success' : 'text-danger'); ?>">
                                    $<?php echo e(number_format($trade->profit_loss, 2)); ?>

                                </td>
                                <td>
                                    <span class="badge bg-<?php echo e($trade->status === 'filled' ? 'success' : ($trade->status === 'pending' ? 'warning' : 'secondary')); ?>">
                                        <?php echo e(ucfirst($trade->status)); ?>

                                    </span>
                                </td>
                                <td><?php echo e($trade->created_at->format('M d, Y H:i')); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="d-flex justify-content-center">
                    <?php echo e($trades->links()); ?>

                </div>
                <?php else: ?>
                <div class="text-center py-5">
                    <i class="bi bi-graph-up display-1 text-muted"></i>
                    <h4 class="text-muted mt-3">No trades yet</h4>
                    <p class="text-muted">Start by creating an AI agent to begin trading.</p>
                    <a href="<?php echo e(route('customer.agents.create')); ?>" class="btn btn-primary">
                        <i class="bi bi-robot"></i> Create AI Agent
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-robot"></i> Active Agents</h5>
            </div>
            <div class="card-body">
                <?php if($agents->count() > 0): ?>
                    <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h6 class="mb-0"><?php echo e($agent->name); ?></h6>
                            <small class="text-muted"><?php echo e(ucfirst($agent->strategy)); ?></small>
                        </div>
                        <div class="text-end">
                            <div class="text-success">$<?php echo e(number_format($agent->current_balance, 2)); ?></div>
                            <small class="text-muted">Balance</small>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <div class="text-center py-3">
                    <i class="bi bi-robot display-4 text-muted"></i>
                    <p class="text-muted mt-2">No active agents</p>
                    <a href="<?php echo e(route('customer.agents.create')); ?>" class="btn btn-primary btn-sm">
                        Create Agent
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="card mt-3">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-lightning"></i> Quick Actions</h5>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <a href="<?php echo e(route('customer.agents.create')); ?>" class="btn btn-primary">
                        <i class="bi bi-robot"></i> Create AI Agent
                    </a>
                    <a href="<?php echo e(route('customer.market.index')); ?>" class="btn btn-info">
                        <i class="bi bi-currency-exchange"></i> View Market
                    </a>
                    <a href="<?php echo e(route('customer.wallet.index')); ?>" class="btn btn-success">
                        <i class="bi bi-wallet2"></i> Manage Wallet
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.customer-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\ai-trade-app\resources\views/customer/trading/index.blade.php ENDPATH**/ ?>