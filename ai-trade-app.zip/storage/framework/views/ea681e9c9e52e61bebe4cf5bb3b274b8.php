<?php
    $setting = \App\Models\Setting::get();
    $logoUrl = $setting->logo_url ?? asset('admin-assets/img/AdminLTELogo.png');
    $projectName = $setting->company_name ?? config('app.name', 'Admin Panel');
?>
<aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
    <div class="sidebar-brand">
        <a href="<?php echo e(url('/')); ?>" class="brand-link">
            <img src="<?php echo e($logoUrl); ?>" alt="Logo" class="brand-image opacity-75 shadow">
            <span class="brand-text fw-light"><?php echo e($projectName); ?></span>
        </a>
    </div>
    <div class="sidebar-wrapper">
        
        <nav class="mt-2">
            <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview">
                <li class="nav-item">
                    <a href="<?php echo e(route('dashboard')); ?>" class="nav-link <?php if(request()->routeIs('dashboard')): ?> active <?php endif; ?>">
                        <i class="nav-icon bi bi-palette"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('admin.deposits.index')); ?>" class="nav-link <?php if(request()->routeIs('admin.deposits.*')): ?> active <?php endif; ?>">
                        <i class="nav-icon bi bi-wallet2"></i>
                        <p>
                            <?php echo e(__('All Deposits')); ?>

                            <?php if(isset($pendingDepositsCount) && $pendingDepositsCount > 0): ?>
                                <span class="badge bg-warning float-end"><?php echo e($pendingDepositsCount); ?></span>
                            <?php endif; ?>
                        </p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('admin.invoices.index')); ?>" class="nav-link <?php if(request()->routeIs('admin.invoices.*')): ?> active <?php endif; ?>">
                        <i class="nav-icon bi bi-file-earmark-text"></i>
                        <p><?php echo e(__('Manage Invoices')); ?></p>
                    </a>
                </li>

                <li class="nav-item menu-open">
                    <a href="#" class="nav-link">
                        <i class="nav-icon bi bi-gear"></i>
                        <p>
                            Settings
                            <i class="nav-arrow bi bi-chevron-right"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.users.index')); ?>" class="nav-link <?php if(request()->routeIs('admin.users.index')): ?> active <?php endif; ?>">
                                <i class="nav-icon bi bi-circle"></i>
                                <p><?php echo e(__('Manage Users')); ?></p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.roles.index')); ?>" class="nav-link <?php if(request()->routeIs('admin.roles.index')): ?> active <?php endif; ?>">
                                <i class="nav-icon bi bi-circle"></i>
                                <p><?php echo e(__('Manage Roles')); ?></p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.plans.index')); ?>" class="nav-link <?php if(request()->routeIs('admin.plans.*')): ?> active <?php endif; ?>">
                                <i class="nav-icon bi bi-circle"></i>
                                <p><?php echo e(__('Manage Sharing(NEXA) Plans')); ?></p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.rent-bot-packages.index')); ?>" class="nav-link <?php if(request()->routeIs('admin.rent-bot-packages.*')): ?> active <?php endif; ?>">
                                <i class="nav-icon bi bi-circle"></i>
                                <p><?php echo e(__('Manage Rent a Bot Plans')); ?></p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.wallet-addresses.index')); ?>" class="nav-link <?php if(request()->routeIs('admin.wallet-addresses.*')): ?> active <?php endif; ?>">
                                <i class="nav-icon bi bi-circle"></i>
                                <p><?php echo e(__('Deposits Admin Details')); ?></p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.settings.index')); ?>" class="nav-link <?php if(request()->routeIs('admin.settings.*')): ?> active <?php endif; ?>">
                                <i class="nav-icon bi bi-circle"></i>
                                <p><?php echo e(__('Logo & Project Name')); ?></p>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
    </div>
</aside>
<?php /**PATH D:\laragon\www\ai-trade-app\resources\views/layouts/admin-includes/leftmenu.blade.php ENDPATH**/ ?>