<?php $__env->startSection('title', 'Admin Dashboard - AI Trade App'); ?>
<?php $__env->startSection('page-title', 'Admin Dashboard'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .stats-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-radius: 15px;
        padding: 1.5rem;
        margin-bottom: 1rem;
    }
    
    .stats-card h3 {
        font-size: 2.5rem;
        font-weight: bold;
        margin: 0;
    }
    
    .stats-card p {
        margin: 0;
        opacity: 0.9;
    }
    
    .revenue-card {
        background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
    }
    
    .users-card {
        background: linear-gradient(135deg, #ff416c 0%, #ff4b2b 100%);
    }
    
    .trades-card {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
    }
    
    .agents-card {
        background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
    }
    
    .chart-container {
        position: relative;
        height: 300px;
    }
    
    .activity-item {
        padding: 10px 0;
        border-bottom: 1px solid #eee;
    }
    
    .activity-item:last-child {
        border-bottom: none;
    }
    
    .quick-action-btn {
        height: 100%;
        min-height: 90px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        padding: 1rem;
        transition: transform 0.2s ease;
    }
    
    .quick-action-btn:hover {
        transform: translateY(-2px);
    }
    
    .quick-action-btn i {
        font-size: 1.5rem;
        margin-bottom: 0.5rem;
    }
    
    .quick-action-btn small {
        font-size: 0.75rem;
        margin-top: 0.5rem;
        display: block;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<!-- Statistics Cards -->
<div class="row">
    <div class="col-md-3 mb-4">
        <div class="stats-card users-card">
            <h3><?php echo e($totalUsers); ?></h3>
            <p>Total Users</p>
            <small><?php echo e($activeUsers); ?> active</small>
        </div>
    </div>
    
    <div class="col-md-3 mb-4">
        <div class="stats-card trades-card">
            <h3><?php echo e($totalTrades); ?></h3>
            <p>Total Trades</p>
            <small><?php echo e($activeTrades); ?> active</small>
        </div>
    </div>
    
    <div class="col-md-3 mb-4">
        <div class="stats-card revenue-card">
            <h3>$<?php echo e(number_format($adminProfit, 2)); ?></h3>
            <p>Admin Profit</p>
            <small>50% of total profit</small>
        </div>
    </div>
    
    <div class="col-md-3 mb-4">
        <div class="stats-card agents-card">
            <h3><?php echo e($totalAgents); ?></h3>
            <p>AI Agents</p>
            <small><?php echo e($activeAgents); ?> active</small>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="row">
    <div class="col-12 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-lightning"></i> Quick Actions</h5>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-2 col-sm-4">
                        <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-primary w-100 quick-action-btn">
                            <i class="bi bi-people"></i>
                            <span>Manage Users</span>
                            <small class="badge bg-light text-dark mt-1"><?php echo e($totalUsersCount); ?> Total</small>
                        </a>
                    </div>
                    <div class="col-md-2 col-sm-4">
                        <a href="<?php echo e(route('admin.deposits.index')); ?>" class="btn btn-success w-100 quick-action-btn">
                            <i class="bi bi-wallet2"></i>
                            <span>All Deposits</span>
                            <small class="badge bg-light text-dark mt-1">
                                <?php echo e($totalDepositsCount); ?> Total
                                <?php if($pendingDeposits > 0): ?>
                                    <span class="badge bg-warning ms-1"><?php echo e($pendingDeposits); ?> Pending</span>
                                <?php endif; ?>
                            </small>
                        </a>
                    </div>
                    <div class="col-md-2 col-sm-4">
                        <a href="<?php echo e(route('admin.transactions.index')); ?>" class="btn btn-info w-100 quick-action-btn">
                            <i class="bi bi-arrow-left-right"></i>
                            <span>View Transactions</span>
                            <small class="badge bg-light text-dark mt-1"><?php echo e($totalTransactionsCount); ?> Total</small>
                        </a>
                    </div>
                    <div class="col-md-2 col-sm-4">
                        <a href="<?php echo e(route('admin.trades.index')); ?>" class="btn btn-warning w-100 quick-action-btn">
                            <i class="bi bi-graph-up"></i>
                            <span>View Trades</span>
                            <small class="badge bg-light text-dark mt-1"><?php echo e($totalTradesCount); ?> Total</small>
                        </a>
                    </div>
                    <div class="col-md-2 col-sm-4">
                        <a href="<?php echo e(route('admin.agents.index')); ?>" class="btn btn-secondary w-100 quick-action-btn">
                            <i class="bi bi-robot"></i>
                            <span>Manage Agents</span>
                            <small class="badge bg-light text-dark mt-1"><?php echo e($totalAgentsCount); ?> Total</small>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Revenue Overview -->
    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-graph-up"></i> Revenue Overview</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6>Total Deposits</h6>
                        <h3 class="text-success">$<?php echo e(number_format($totalDeposits, 2)); ?></h3>
                    </div>
                    <div class="col-md-6">
                        <h6>Total Withdrawals</h6>
                        <h3 class="text-danger">$<?php echo e(number_format($totalWithdrawals, 2)); ?></h3>
                    </div>
                </div>
                
                <hr>
                
                <div class="row">
                    <div class="col-md-6">
                        <h6>Total Profit</h6>
                        <h3 class="text-primary">$<?php echo e(number_format($totalProfit, 2)); ?></h3>
                    </div>
                    <div class="col-md-6">
                        <h6>Admin Share (50%)</h6>
                        <h3 class="text-warning">$<?php echo e(number_format($adminProfit, 2)); ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Pending Items -->
    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-clock"></i> Pending Items</h5>
            </div>
            <div class="card-body">
                <div class="row text-center">
                    <div class="col-6">
                        <h4 class="text-warning"><?php echo e($pendingTransactions); ?></h4>
                        <small>Pending Transactions</small>
                    </div>
                    <div class="col-6">
                        <h4 class="text-info"><?php echo e($pendingMessages->count()); ?></h4>
                        <small>Open Messages</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Recent Activities -->
<div class="row">
    <!-- Recent Users -->
    <div class="col-md-4 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-people"></i> Recent Users</h5>
            </div>
            <div class="card-body">
                <div class="recent-activity">
                    <?php $__empty_1 = true; $__currentLoopData = $recentUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="activity-item">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <strong><?php echo e($user->name); ?></strong>
                                <br>
                                <small class="text-muted"><?php echo e($user->email); ?></small>
                            </div>
                            <div class="text-end">
                                <span class="badge bg-<?php echo e($user->is_active ? 'success' : 'secondary'); ?>">
                                    <?php echo e($user->is_active ? 'Active' : 'Inactive'); ?>

                                </span>
                                <br>
                                <small class="text-muted"><?php echo e($user->created_at->format('M d, Y')); ?></small>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted">No recent users found.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Recent Trades -->
    <div class="col-md-4 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-graph-up"></i> Recent Trades</h5>
            </div>
            <div class="card-body">
                <div class="recent-activity">
                    <?php $__empty_1 = true; $__currentLoopData = $recentTrades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="activity-item">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <strong><?php echo e($trade->symbol); ?></strong>
                                <br>
                                <small class="text-muted"><?php echo e($trade->user->name); ?></small>
                            </div>
                            <div class="text-end">
                                <span class="badge bg-<?php echo e($trade->side === 'buy' ? 'success' : 'danger'); ?>">
                                    <?php echo e(strtoupper($trade->side)); ?>

                                </span>
                                <br>
                                <small class="<?php echo e($trade->profit_loss >= 0 ? 'text-success' : 'text-danger'); ?>">
                                    $<?php echo e(number_format($trade->profit_loss, 2)); ?>

                                </small>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted">No recent trades found.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Recent Transactions -->
    <div class="col-md-4 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-arrow-left-right"></i> Recent Transactions</h5>
            </div>
            <div class="card-body">
                <div class="recent-activity">
                    <?php $__empty_1 = true; $__currentLoopData = $recentTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="activity-item">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <strong><?php echo e(ucfirst($transaction->type)); ?></strong>
                                <br>
                                <small class="text-muted"><?php echo e($transaction->user->name); ?></small>
                            </div>
                            <div class="text-end">
                                <span class="badge bg-<?php echo e($transaction->status === 'completed' ? 'success' : ($transaction->status === 'pending' ? 'warning' : 'secondary')); ?>">
                                    <?php echo e(ucfirst($transaction->status)); ?>

                                </span>
                                <br>
                                <small class="<?php echo e($transaction->type === 'deposit' ? 'text-success' : 'text-danger'); ?>">
                                    $<?php echo e(number_format($transaction->amount, 2)); ?>

                                </small>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted">No recent transactions found.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Pending Messages -->
<?php if($pendingMessages->count() > 0): ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-chat-dots"></i> Pending Support Messages</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Subject</th>
                                <th>Type</th>
                                <th>Priority</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pendingMessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($message->user->name); ?></td>
                                <td><?php echo e($message->subject); ?></td>
                                <td>
                                    <span class="badge bg-info"><?php echo e(ucfirst($message->type)); ?></span>
                                </td>
                                <td>
                                    <span class="badge bg-<?php echo e($message->priority === 'urgent' ? 'danger' : ($message->priority === 'high' ? 'warning' : 'secondary')); ?>">
                                        <?php echo e(ucfirst($message->priority)); ?>

                                    </span>
                                </td>
                                <td><?php echo e($message->created_at->format('M d, Y H:i')); ?></td>
                                <td>
                                    <a href="#" class="btn btn-sm btn-primary">View</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Auto-refresh dashboard data every 30 seconds
    setInterval(function() {
        // You can add AJAX calls here to refresh data
        console.log('Refreshing admin dashboard data...');
    }, 30000);
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\ai-trade-app\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>