<footer class="app-footer">
    <div class="float-end d-none d-sm-inline">Anything you want</div>
    <strong>Copyright &copy; 2014-{{ date('Y') }}
        <a href="#" class="text-decoration-none">Admin Panel</a>.
    </strong> All rights reserved.
</footer>
