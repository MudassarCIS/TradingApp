<footer class="app-footer">
    <div class="float-end d-none d-sm-inline">Anything you want</div>
    <strong>Copyright &copy; 2014-<?php echo e(date('Y')); ?>

        <a href="#" class="text-decoration-none">Admin Panel</a>.
    </strong> All rights reserved.
</footer>
<?php /**PATH D:\laragon\www\TradingApp\resources\views/layouts/admin-includes/footer.blade.php ENDPATH**/ ?>