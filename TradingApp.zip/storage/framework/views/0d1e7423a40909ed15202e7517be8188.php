<?php $__env->startSection('title', 'Manage NEXA Plans'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h3 class="card-title">NEXA Plans Management</h3>
                    <a href="<?php echo e(route('admin.plans.create')); ?>" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Add New NEXA Plan
                    </a>
                </div>
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table id="plans-table" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Investment Amount</th>
                                    <th>Joining Fee</th>
                                    <th>Bots Allowed</th>
                                    <th>Trades/Day</th>
                                    <th>Direct Bonus</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    $('#plans-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('admin.plans.index')); ?>",
        columns: [
            {data: 'id', name: 'id'},
            {data: 'name', name: 'name'},
            {data: 'investment_amount', name: 'investment_amount'},
            {data: 'joining_fee', name: 'joining_fee'},
            {data: 'bots_allowed', name: 'bots_allowed'},
            {data: 'trades_per_day', name: 'trades_per_day'},
            {data: 'direct_bonus', name: 'direct_bonus'},
            {data: 'status', name: 'is_active'},
            {data: 'action', name: 'action', orderable: false, searchable: false}
        ],
        responsive: true,
        pageLength: 25,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]]
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\TradingApp\resources\views/admin/plans/index.blade.php ENDPATH**/ ?>