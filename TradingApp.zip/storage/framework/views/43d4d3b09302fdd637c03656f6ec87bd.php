<?php $__env->startSection('title', 'Invoice Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h3 class="card-title">Invoice Details</h3>
                    <a href="<?php echo e(route('admin.invoices.index')); ?>" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to Invoices
                    </a>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <table class="table table-bordered">
                                <tr>
                                    <th width="40%">Invoice Number:</th>
                                    <td><strong><?php echo e($invoice->formatted_invoice_id); ?></strong></td>
                                </tr>
                                <tr>
                                    <th>Invoice Type:</th>
                                    <td><?php echo e($invoice->invoice_type); ?></td>
                                </tr>
                                <tr>
                                    <th>Amount:</th>
                                    <td><strong>$<?php echo e(number_format($invoice->amount, 2)); ?> USDT</strong></td>
                                </tr>
                                <tr>
                                    <th>Due Date:</th>
                                    <td><?php echo e($invoice->due_date->format('d/m/Y')); ?></td>
                                </tr>
                                <tr>
                                    <th>Status:</th>
                                    <td>
                                        <?php if($invoice->status === 'Paid'): ?>
                                            <span class="badge bg-success">Paid</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning">Unpaid</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Created At:</th>
                                    <td><?php echo e($invoice->created_at->format('d/m/Y H:i')); ?></td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <h5>Customer Information</h5>
                            <table class="table table-bordered">
                                <tr>
                                    <th width="40%">Customer Name:</th>
                                    <td><?php echo e($invoice->user->name ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <th>Email:</th>
                                    <td><?php echo e($invoice->user->email ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <th>Customer ID:</th>
                                    <td><?php echo e($invoice->user_id); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\TradingApp\resources\views/admin/invoices/show.blade.php ENDPATH**/ ?>