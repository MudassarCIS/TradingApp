<?php $__env->startSection('title', 'Roles Mgm'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Roles</h2>
        <table class="table table-bordered">
            <thead>
            <tr>
                <th>Role</th><th>Permissions</th><th>Actions</th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($role->name); ?></td>
                    <td><?php echo e($role->permissions->pluck('name')->implode(', ')); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.roles.edit', $role)); ?>" class="btn btn-warning btn-sm">Edit Permissions</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\TradingApp\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>